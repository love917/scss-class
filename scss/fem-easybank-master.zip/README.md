# Frontend Mentor - Easybank challenge

<a href="https://www.youtube.com/playlist?list=PLUWqFDiirlsuYscECzks6zIZWr_Cfcx9k"><img src="https://i.imgur.com/tg5xw3w.jpg" alt="Image showing Coder Coder dressed in construction vest with hard hat and tools, title says Let's Build a Website with HTML and CSS, Part 1"></a>

This is the source code from my YouTube video series, [Build a Reponsive Website from Scratch](https://www.youtube.com/playlist?list=PLUWqFDiirlsuYscECzks6zIZWr_Cfcx9k).

Check out the final website [here](https://codercoder-easybank.pages.dev/)!

If my videos helped you at all, consider [sponsoring me on GitHub](https://github.com/sponsors/thecodercoder) to support more free coding tutorials on my YouTube channel, Coder Coder!
